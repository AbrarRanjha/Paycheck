const CommissionSplitService =require ('./service.js');

class CommissionSplitController {
  constructor() {}
  async getCommissionSplitById(req, res) {
    try {
      const id = req.params.id;
      const CommissionSplit = await CommissionSplitService.getCommissionSplitById(id);
      if (CommissionSplit) {
        res.status(200).json(CommissionSplit);
      } else {
        res.status(404).json({ error: 'CommissionSplit not found' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
  async getCommissionSplit(req, res) {
    try {
      const {limit,skip}=req.query  
      if(!limit||!skip){
        res.status(400).json({ error: 'Limit or skip is undefined' });
      }    
      const CommissionSplit = await CommissionSplitService.getAllCommissionSplit(limit,skip);
      if (CommissionSplit) {
        res.status(200).json(CommissionSplit);
      } else {
        res.status(404).json({ error: 'CommissionSplit not found' });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

}

module.exports = new CommissionSplitController()